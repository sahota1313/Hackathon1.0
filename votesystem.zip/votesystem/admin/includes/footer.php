<footer class="main-footer" style="background-color: #717A83 ">
    <div class="pull-right hidden-xs "  style="color:white ; font-size: 13px"  >
      <b>All rights reserved</b>
    </div  >
    <b style="color:white ; font-size: 13px"><strong>Copyright &copy; Tripta </strong></b>
</footer>